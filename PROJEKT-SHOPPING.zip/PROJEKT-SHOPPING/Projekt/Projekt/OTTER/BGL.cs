﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Media;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace OTTER
{
    /// <summary>
    /// -
    /// </summary>
    public partial class BGL : Form
    {
        /* ------------------- */
        #region Environment Variables

        List<Func<int>> GreenFlagScripts = new List<Func<int>>();

        /// <summary>
        /// Uvjet izvršavanja igre. Ako je <c>START == true</c> igra će se izvršavati.
        /// </summary>
        /// <example><c>START</c> se često koristi za beskonačnu petlju. Primjer metode/skripte:
        /// <code>
        /// private int MojaMetoda()
        /// {
        ///     while(START)
        ///     {
        ///       //ovdje ide kod
        ///     }
        ///     return 0;
        /// }</code>
        /// </example>
        public static bool START = true;

        //sprites
        /// <summary>
        /// Broj likova.
        /// </summary>
        public static int spriteCount = 0, soundCount = 0;

        /// <summary>
        /// Lista svih likova.
        /// </summary>
        //public static List<Sprite> allSprites = new List<Sprite>();
        public static SpriteList<Sprite> allSprites = new SpriteList<Sprite>();

        //sensing
        int mouseX, mouseY;
        Sensing sensing = new Sensing();

        //background
        List<string> backgroundImages = new List<string>();
        int backgroundImageIndex = 0;
        string ISPIS = "";

        SoundPlayer[] sounds = new SoundPlayer[1000];
        TextReader[] readFiles = new StreamReader[1000];
        TextWriter[] writeFiles = new StreamWriter[1000];
        bool showSync = false;
        int loopcount;
        DateTime dt = new DateTime();
        String time;
        double lastTime, thisTime, diff;

        #endregion
        /* ------------------- */
        #region Events

        private void Draw(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            try
            {                
                foreach (Sprite sprite in allSprites)
                {                    
                    if (sprite != null)
                        if (sprite.Show == true)
                        {
                            g.DrawImage(sprite.CurrentCostume, new Rectangle(sprite.X, sprite.Y, sprite.Width, sprite.Heigth));
                        }
                    if (allSprites.Change)
                        break;
                }
                if (allSprites.Change)
                    allSprites.Change = false;
            }
            catch
            {
                //ako se doda sprite dok crta onda se mijenja allSprites
                MessageBox.Show("Greška!");
            }
        }

        private void startTimer(object sender, EventArgs e)
        {
            //this.Izbornik.Hide();
            timer1.Start();
            timer2.Start();
            Init();
        }

        private void updateFrameRate(object sender, EventArgs e)
        {
            updateSyncRate();
        }

        /// <summary>
        /// Crta tekst po pozornici.
        /// </summary>
        /// <param name="sender">-</param>
        /// <param name="e">-</param>
        public void DrawTextOnScreen(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            var brush = new SolidBrush(Color.WhiteSmoke);
            string text = ISPIS;

            SizeF stringSize = new SizeF();
            Font stringFont = new Font("Arial", 14);
            stringSize = e.Graphics.MeasureString(text, stringFont);

            using (Font font1 = stringFont)
            {
                RectangleF rectF1 = new RectangleF(0, 0, stringSize.Width, stringSize.Height);
                e.Graphics.FillRectangle(brush, Rectangle.Round(rectF1));
                e.Graphics.DrawString(text, font1, Brushes.Black, rectF1);
            }
        }

        private void mouseClicked(object sender, MouseEventArgs e)
        {
            //sensing.MouseDown = true;
            sensing.MouseDown = true;
        }

        private void mouseDown(object sender, MouseEventArgs e)
        {
            //sensing.MouseDown = true;
            sensing.MouseDown = true;            
        }

        private void mouseUp(object sender, MouseEventArgs e)
        {
            //sensing.MouseDown = false;
            sensing.MouseDown = false;
        }

        private void mouseMove(object sender, MouseEventArgs e)
        {
            mouseX = e.X;
            mouseY = e.Y;

            //sensing.MouseX = e.X;
            //sensing.MouseY = e.Y;
            //Sensing.Mouse.x = e.X;
            //Sensing.Mouse.y = e.Y;
            sensing.Mouse.X = e.X;
            sensing.Mouse.Y = e.Y;

        }

        private void keyDown(object sender, KeyEventArgs e)
        {
            sensing.Key = e.KeyCode.ToString();
            sensing.KeyPressedTest = true;
        }

        private void keyUp(object sender, KeyEventArgs e)
        {
            sensing.Key = "";
            sensing.KeyPressedTest = false;
        }

        private void Update(object sender, EventArgs e)
        {
            if (sensing.KeyPressed(Keys.Escape))
            {
                START = false;
            }

            if (START)
            {
                this.Refresh();
            }
        }

        #endregion
        /* ------------------- */
        #region Start of Game Methods

        //my
        #region my

        //private void StartScriptAndWait(Func<int> scriptName)
        //{
        //    Task t = Task.Factory.StartNew(scriptName);
        //    t.Wait();
        //}

        //private void StartScript(Func<int> scriptName)
        //{
        //    Task t;
        //    t = Task.Factory.StartNew(scriptName);
        //}

        private int AnimateBackground(int intervalMS)
        {
            while (START)
            {
                setBackgroundPicture(backgroundImages[backgroundImageIndex]);
                Game.WaitMS(intervalMS);
                backgroundImageIndex++;
                if (backgroundImageIndex == 3)
                    backgroundImageIndex = 0;
            }
            return 0;
        }

        private void KlikNaZastavicu()
        {
            foreach (Func<int> f in GreenFlagScripts)
            {
                Task.Factory.StartNew(f);
            }
        }

        #endregion

        /// <summary>
        /// BGL
        /// </summary>
        public BGL()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Pričekaj (pauza) u sekundama.
        /// </summary>
        /// <example>Pričekaj pola sekunde: <code>Wait(0.5);</code></example>
        /// <param name="sekunde">Realan broj.</param>
        public void Wait(double sekunde)
        {
            int ms = (int)(sekunde * 1000);
            Thread.Sleep(ms);
        }

        //private int SlucajanBroj(int min, int max)
        //{
        //    Random r = new Random();
        //    int br = r.Next(min, max + 1);
        //    return br;
        //}

        /// <summary>
        /// -
        /// </summary>
        public void Init()
        {
            if (dt == null) time = dt.TimeOfDay.ToString();
            loopcount++;
            //Load resources and level here
            this.Paint += new PaintEventHandler(DrawTextOnScreen);
            //timer3.Tick += new EventHandler(timer3_Tick);
           // timer3.Interval = 10000; // in miliseconds
            SetupGame();
        }

        /// <summary>
        /// -
        /// </summary>
        /// <param name="val">-</param>
        public void showSyncRate(bool val)
        {
            showSync = val;
            if (val == true) syncRate.Show();
            if (val == false) syncRate.Hide();
        }

        /// <summary>
        /// -
        /// </summary>
        public void updateSyncRate()
        {
            if (showSync == true)
            {
                thisTime = (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0)).TotalSeconds;
                diff = thisTime - lastTime;
                lastTime = (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0)).TotalSeconds;

                double fr = (1000 / diff) / 1000;

                int fr2 = Convert.ToInt32(fr);

                syncRate.Text = fr2.ToString();
            }

        }

        //stage
        #region Stage

        /// <summary>
        /// Postavi naslov pozornice.
        /// </summary>
        /// <param name="title">tekst koji će se ispisati na vrhu (naslovnoj traci).</param>
        public void SetStageTitle(string title)
        {
            this.Text = title;
        }

        /// <summary>
        /// Postavi boju pozadine.
        /// </summary>
        /// <param name="r">r</param>
        /// <param name="g">g</param>
        /// <param name="b">b</param>
        public void setBackgroundColor(int r, int g, int b)
        {
            this.BackColor = Color.FromArgb(r, g, b);
        }

        /// <summary>
        /// Postavi boju pozornice. <c>Color</c> je ugrađeni tip.
        /// </summary>
        /// <param name="color"></param>
        public void setBackgroundColor(Color color)
        {
            this.BackColor = color;
        }

        /// <summary>
        /// Postavi sliku pozornice.
        /// </summary>
        /// <param name="backgroundImage">Naziv (putanja) slike.</param>
        public void setBackgroundPicture(string backgroundImage)
        {
            this.BackgroundImage = new Bitmap(backgroundImage);
        }

        /// <summary>
        /// Izgled slike.
        /// </summary>
        /// <param name="layout">none, tile, stretch, center, zoom</param>
        public void setPictureLayout(string layout)
        {
            if (layout.ToLower() == "none") this.BackgroundImageLayout = ImageLayout.None;
            if (layout.ToLower() == "tile") this.BackgroundImageLayout = ImageLayout.Tile;
            if (layout.ToLower() == "stretch") this.BackgroundImageLayout = ImageLayout.Stretch;
            if (layout.ToLower() == "center") this.BackgroundImageLayout = ImageLayout.Center;
            if (layout.ToLower() == "zoom") this.BackgroundImageLayout = ImageLayout.Zoom;
        }

        #endregion

        //sound
        #region sound methods

        /// <summary>
        /// Učitaj zvuk.
        /// </summary>
        /// <param name="soundNum">-</param>
        /// <param name="file">-</param>
        public void loadSound(int soundNum, string file)
        {
            soundCount++;
            sounds[soundNum] = new SoundPlayer(file);
        }

        /// <summary>
        /// Sviraj zvuk.
        /// </summary>
        /// <param name="soundNum">-</param>
        public void playSound(int soundNum)
        {
            sounds[soundNum].Play();
        }

        /// <summary>
        /// loopSound
        /// </summary>
        /// <param name="soundNum">-</param>
        public void loopSound(int soundNum)
        {
            sounds[soundNum].PlayLooping();
        }

        /// <summary>
        /// Zaustavi zvuk.
        /// </summary>
        /// <param name="soundNum">broj</param>
        public void stopSound(int soundNum)
        {
            sounds[soundNum].Stop();
        }

        #endregion

        //file
        #region file methods

        /// <summary>
        /// Otvori datoteku za čitanje.
        /// </summary>
        /// <param name="fileName">naziv datoteke</param>
        /// <param name="fileNum">broj</param>
        public void openFileToRead(string fileName, int fileNum)
        {
            readFiles[fileNum] = new StreamReader(fileName);
        }

        /// <summary>
        /// Zatvori datoteku.
        /// </summary>
        /// <param name="fileNum">broj</param>
        public void closeFileToRead(int fileNum)
        {
            readFiles[fileNum].Close();
        }

        /// <summary>
        /// Otvori datoteku za pisanje.
        /// </summary>
        /// <param name="fileName">naziv datoteke</param>
        /// <param name="fileNum">broj</param>
        public void openFileToWrite(string fileName, int fileNum)
        {
            writeFiles[fileNum] = new StreamWriter(fileName);
        }

        /// <summary>
        /// Zatvori datoteku.
        /// </summary>
        /// <param name="fileNum">broj</param>
        public void closeFileToWrite(int fileNum)
        {
            writeFiles[fileNum].Close();
        }

        /// <summary>
        /// Zapiši liniju u datoteku.
        /// </summary>
        /// <param name="fileNum">broj datoteke</param>
        /// <param name="line">linija</param>
        public void writeLine(int fileNum, string line)
        {
            writeFiles[fileNum].WriteLine(line);
        }

        /// <summary>
        /// Pročitaj liniju iz datoteke.
        /// </summary>
        /// <param name="fileNum">broj datoteke</param>
        /// <returns>vraća pročitanu liniju</returns>
        public string readLine(int fileNum)
        {
            return readFiles[fileNum].ReadLine();
        }

        /// <summary>
        /// Čita sadržaj datoteke.
        /// </summary>
        /// <param name="fileNum">broj datoteke</param>
        /// <returns>vraća sadržaj</returns>
        public string readFile(int fileNum)
        {
            return readFiles[fileNum].ReadToEnd();
        }

        #endregion

        //mouse & keys
        #region mouse methods

        /// <summary>
        /// Sakrij strelicu miša.
        /// </summary>
        public void hideMouse()
        {
            Cursor.Hide();
        }

        /// <summary>
        /// Pokaži strelicu miša.
        /// </summary>
        public void showMouse()
        {
            Cursor.Show();
        }

        /// <summary>
        /// Provjerava je li miš pritisnut.
        /// </summary>
        /// <returns>true/false</returns>
        public bool isMousePressed()
        {
            //return sensing.MouseDown;
            return sensing.MouseDown;
        }

        /// <summary>
        /// Provjerava je li tipka pritisnuta.
        /// </summary>
        /// <param name="key">naziv tipke</param>
        /// <returns></returns>
        public bool isKeyPressed(string key)
        {
            if (sensing.Key == key)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Provjerava je li tipka pritisnuta.
        /// </summary>
        /// <param name="key">tipka</param>
        /// <returns>true/false</returns>
        public bool isKeyPressed(Keys key)
        {
            if (sensing.Key == key.ToString())
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion

        #endregion
        /* ------------------- */

        /* ------------ GAME CODE START ------------ */

        /* Game variables */
        GlavniLik glavni;
        Stvari stokn, dvjestokn, petstokn, lopov,lopov1,lopov2;
        Stvari duksa, kravata, kupaci, sesir, stikle, torba, vesta, pomocni;
        Sprite start;
        Sprite pozadinaZare;
        List<Stvari> listaRobe;
        List<Stvari> dozvoljenaRoba;

        public Form Izbornik;
        Random r = new Random();

        private delegate void IspisEvent();
        private event IspisEvent Ispis;
        private delegate void PobjedaEvent();
        private event PobjedaEvent Pobjedakraj;
        private delegate void IspisRobeEvent();
        private event IspisRobeEvent IspisRobe;
        /* Initialization */


        private void SetupGame()
        {
            //1. setup stage
            SetStageTitle("SHOPPING");
            setBackgroundColor(Color.WhiteSmoke);            
            setBackgroundPicture("backgrounds\\prvinivo.jpg");
            //none, tile, stretch, center, zoom
            setPictureLayout("stretch");

            //2. add sprites
            glavni = new GlavniLik("sprites\\lik2.png", 0, 0);
            glavni.SetSize(30);
            Game.AddSprite(glavni);

            lopov = new Stvari("sprites\\lopov.png", GameOptions.RightEdge - 100, 0);
            lopov.SetVisible(false);
            lopov.SetSize(10);
            Game.AddSprite(lopov);

            stokn = new Stvari("sprites\\100.png", GameOptions.RightEdge - 100, 0);
            stokn.SetVisible(false);
            stokn.SetSize(10);
            Game.AddSprite(stokn);

            dvjestokn = new Stvari("sprites\\200.png", GameOptions.RightEdge - 100, 0);
            dvjestokn.SetVisible(false);
            dvjestokn.SetSize(10);
            Game.AddSprite(dvjestokn);

            petstokn = new Stvari("sprites\\500.png", GameOptions.RightEdge - 100, 0);
            petstokn.SetVisible(false);
            petstokn.SetSize(10);
            Game.AddSprite(petstokn);

            start = new Sprite("sprites\\start.png",300,380);
            start.SetSize(50);
            Game.AddSprite(start);
            start.SetVisible(false);

            pozadinaZare = new Sprite("backgrounds\\muski1.jpg", 0, 0);
            Game.AddSprite(pozadinaZare);
            pozadinaZare.SetVisible(false);

            lopov1 = new Stvari("sprites\\lopov.png", GameOptions.RightEdge - 100, 0);
            lopov1.SetVisible(false);
            lopov1.SetSize(10);
            Game.AddSprite(lopov1);

            lopov2 = new Stvari("sprites\\lopov.png", GameOptions.RightEdge - 100, 0);
            lopov2.SetVisible(false);
            lopov2.SetSize(10);
            Game.AddSprite(lopov2);

            duksa = new Stvari("sprites\\duksa.png", GameOptions.RightEdge - 200, 150);
            duksa.SetVisible(false);
            duksa.Naziv = "duksa";
            duksa.SetTransparentColor(Color.White);
            duksa.SetSize(80);
            Game.AddSprite(duksa);

            kravata = new Stvari("sprites\\kravata.png", GameOptions.RightEdge - 200, 350);
            kravata.SetVisible(false);
            kravata.Naziv = "kravata";
            kravata.SetTransparentColor(Color.White);
            kravata.SetSize(80);
            Game.AddSprite(kravata);

            kupaci = new Stvari("sprites\\kupaci.png", GameOptions.RightEdge - 200, 400);
            kupaci.SetVisible(false);
            kupaci.Naziv = "kupaci";
            kupaci.SetTransparentColor(Color.White);
            Game.AddSprite(kupaci);

            vesta = new Stvari("sprites\\vesta.png", GameOptions.RightEdge - 200, 0);
            vesta.SetVisible(false);
            vesta.Naziv = "vesta";
            vesta.SetTransparentColor(Color.White);
            Game.AddSprite(vesta);

            sesir = new Stvari("sprites\\sesir.png", GameOptions.RightEdge - 200, 100);
            sesir.SetVisible(false);
            sesir.Naziv = "sesir";
            sesir.SetTransparentColor(Color.White);
            sesir.SetSize(80);
            Game.AddSprite(sesir);

            stikle = new Stvari("sprites\\stikle.png", GameOptions.RightEdge - 200, 200);
            stikle.SetVisible(false);
            stikle.Naziv = "stikle";
            stikle.SetTransparentColor(Color.White);
            stikle.SetSize(75);
            Game.AddSprite(stikle);

            torba = new Stvari("sprites\\torba.png", GameOptions.RightEdge - 200, 300);
            torba.SetVisible(false);
            torba.Naziv = "torba";
            torba.SetTransparentColor(Color.White);
            Game.AddSprite(torba);

            listaRobe = new List<Stvari>();
            listaRobe.Add(kupaci);
            listaRobe.Add(sesir);
            listaRobe.Add(stikle);
            listaRobe.Add(torba);
            listaRobe.Add(vesta);
            listaRobe.Add(kravata);
            listaRobe.Add(duksa);

            //događaji
            Ispis += IspisiRezultat;
            IspisRobe += IspisZaRobu;
            glavni.KrajIgre += GlavniKraj;
            Pobjedakraj += Pobjeda;
            Ispis.Invoke();
            //3. scripts that start
            Game.StartScript(GlavniKretanje);
            Game.StartScript(Stokn);
            Game.StartScript(Dvjestokn);
            Game.StartScript(Petstokn);
            Game.StartScript(LopovKretanje);
            Game.StartScript(Zara);
        }

        /* Scripts */
        #region PRVI_DIO_IGRICE
        private int GlavniKretanje()
        {
            glavni.X = 0;
            glavni.Y = (GameOptions.DownEdge - glavni.Heigth) / 2;
            while (START)
            {
                if (sensing.KeyPressed(Keys.Up))
                    glavni.Y -= glavni.Brzina; //svojstva će se pobrinuti da ne izlazi iz pozornice
                if (sensing.KeyPressed(Keys.Down))
                    glavni.Y += glavni.Brzina;
                if (glavni.TouchingSprite(lopov))
                {
                    Wait(0.1);
                    lopov.SetVisible(false);
                    lopov.X = -100;
                    glavni.BrojZivota--;
                    Ispis.Invoke();
                }
                if (glavni.TouchingSprite(dvjestokn))
                {
                    Wait(0.1);
                    dvjestokn.Dodir = true;
                    glavni.Skupi200+=200;
                    Ispis.Invoke();
                }
                if (glavni.TouchingSprite(stokn))
                {
                    Wait(0.1);
                    stokn.Dodir = true;
                    glavni.Skupi100+=100;
                    Ispis.Invoke();
                }
                if (glavni.TouchingSprite(petstokn))
                {
                    Wait(0.1);
                    petstokn.Dodir = true;
                    glavni.Skupi500 += 500;
                    Ispis.Invoke();
                }
                Wait(0.01);
               
            }
            return 0;
        }
        private int LopovKretanje()
        {
            lopov.X = GameOptions.RightEdge - 110;
            lopov.Y = r.Next(0, GameOptions.DownEdge - 130);
            Wait(0.1);
            lopov.SetVisible(true);
            lopov.Dodir = false;

            while (!lopov.Dodir)
            {

                lopov.X -= 20;
                if (lopov.TouchingEdge())
                {
                    lopov.Y = r.Next(0, GameOptions.DownEdge - 130);
                    Wait(0.1);
                }

                Wait(0.075);
            }

            if (glavni.BrojZivota != 0)
                Game.StartScript(LopovKretanje);
            return 0;
        }
        private int Dvjestokn()
        {
            dvjestokn.X = GameOptions.RightEdge - 110;
            dvjestokn.Y = r.Next(0, GameOptions.DownEdge - 120);
            Wait(0.1);
            dvjestokn.SetVisible(true);
            dvjestokn.Dodir = false;
            while (!dvjestokn.Dodir)
            {
                dvjestokn.X -= 20;
                if (dvjestokn.TouchingEdge())
                {
                    dvjestokn.Y = r.Next(0, GameOptions.DownEdge - 120);
                    Wait(0.1);
                }
                Wait(0.075);
            }
            if (glavni.Skupi1000 < (GameOptions.cilj))
                Game.StartScript(Dvjestokn);
            else
            {
                petstokn.SetVisible(false);
                stokn.SetVisible(false);
                dvjestokn.SetVisible(false);
                petstokn.X = GameOptions.RightEdge;
                petstokn.Y = 0;
                dvjestokn.X = GameOptions.RightEdge;
                dvjestokn.Y = 0;
                stokn.X = GameOptions.RightEdge;
                stokn.Y = 0;
            }

            return 0;
        }
        private int Stokn()
        {
            stokn.GotoXY(GameOptions.RightEdge - 90, r.Next(0, GameOptions.DownEdge - 150));
            Wait(0.1);
            stokn.SetVisible(true);
            stokn.Dodir = false;
            while (!stokn.Dodir)
            {
                stokn.X -= 15;
                if (stokn.TouchingEdge())
                {
                    stokn.Y = r.Next(0, GameOptions.DownEdge - 150);
                    Wait(0.1);
                }
                Wait(0.075);
            }
            if (glavni.Skupi1000 < (GameOptions.cilj))
                Game.StartScript(Stokn);
            else
            {
                petstokn.SetVisible(false);
                stokn.SetVisible(false);
                dvjestokn.SetVisible(false);
                petstokn.X = GameOptions.RightEdge;
                petstokn.Y = 0;
                dvjestokn.X = GameOptions.RightEdge;
                dvjestokn.Y = 0;
                stokn.X = GameOptions.RightEdge;
                stokn.Y = 0;
            }

            return 0;
        }
        private int Petstokn()
        {
            petstokn.GotoXY(GameOptions.RightEdge - 90, r.Next(0, GameOptions.DownEdge - 150));
            Wait(0.1);
            petstokn.SetVisible(true);
            petstokn.Dodir = false;
            while (!petstokn.Dodir)
            {
                petstokn.X -= 10;
                if (petstokn.TouchingEdge())
                {
                    petstokn.Y = r.Next(0, GameOptions.DownEdge - 150);
                    Wait(0.1);
                }
                Wait(0.075);
            }
            if (glavni.Skupi1000 < (GameOptions.cilj))
                Game.StartScript(Petstokn);
            else
            {
                petstokn.SetVisible(false);
                stokn.SetVisible(false);
                dvjestokn.SetVisible(false);
                petstokn.X = GameOptions.RightEdge;
                petstokn.Y = 0;
                dvjestokn.X = GameOptions.RightEdge;
                dvjestokn.Y = 0;
                stokn.X = GameOptions.RightEdge;
                stokn.Y = 0;
            }

            return 0;
        }
        private void IspisiRezultat()
        {
            ISPIS = "Skupljeni novci: " + glavni.Skupi1000 + "/" + GameOptions.cilj.ToString()+ "\nBroj života: " + glavni.BrojZivota + "/" + GameOptions.broj_zivota;
        }
        #endregion
        private void RemoveSprites()
        {
            //vrati brojač na 0
            BGL.spriteCount = 0;
            //izbriši sve spriteove
            BGL.allSprites.Clear();
            //počisti memoriju
            GC.Collect();
        }
       
        private void BGL_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.RemoveSprites();
            glavni.Skupi100 = 0;
            glavni.Skupi200 = 0;
            glavni.Skupi500 = 0;
            glavni.Skupi1000 = 0;
            vesta.Dodir = false;
            stikle.Dodir = false;
            torba.Dodir = false;
            sesir.Dodir = false;
            kupaci.Dodir = false;
            duksa.Dodir = false;
            kravata.Dodir = false;
            this.Izbornik.Show();
        }
        #region DRUGI_DIO_IGRICE
        private int Zara()
        {
            while(START)
            {
                if(glavni.Skupi1000>=1000)
                {
                    Wait(0.1);
                    START = false;
                    ISPIS = "";
                    lopov.SetVisible(false);
                    stokn.SetVisible(false);
                    dvjestokn.SetVisible(false);
                    petstokn.SetVisible(false);
                    glavni.SetVisible(false);
                    setBackgroundPicture("backgrounds\\zara.jpg");
                    setPictureLayout("stretch");
                    start.SetVisible(true);
                    ISPIS = "";
                    glavni.X = 0;
                    glavni.Y = GameOptions.DownEdge - glavni.Heigth;

                    while(!(start.TouchingMousePoint(sensing.Mouse)&&sensing.MouseDown))
                    {
                        
                    }
                    Wait(0.2);
                    setBackgroundPicture("backgrounds\\muski.jpeg");
                    setPictureLayout("stretch");
                    start.SetVisible(false);
                    glavni.SetVisible(true);
                    glavni.SetSize(45);
                    glavni.Y = GameOptions.DownEdge - glavni.Heigth;
                    OdaberiRobu();
                    DodajMusku();
                    IspisRobe.Invoke();
                    Game.StartScript(GlavniuZare);
                    Game.StartScript(Lopov1uZare);
                    Game.StartScript(Lopov2uZare);

                }
            }
            return 0;
        }
        private int GlavniuZare()
        {
            START = true;
            while (START)
            {
                Color boja1 = pozadinaZare.CurrentCostume.GetPixel(sensing.Mouse.X, sensing.Mouse.Y);
                if (boja1.R == 0 && boja1.G == 0 && boja1.B == 0)
                {
                    glavni.GotoXY(sensing.Mouse.X - (glavni.Width / 2), sensing.Mouse.Y - (glavni.Heigth /2));
                }
                if (glavni.TouchingSprite(lopov1))
                {
                    Wait(0.1);
                    lopov1.SetVisible(false);
                    lopov1.X = -100;
                    glavni.BrojZivota--;
                    IspisRobe.Invoke();
                }
                if (glavni.TouchingSprite(lopov2))
                {
                    Wait(0.1);
                    lopov2.SetVisible(false);
                    lopov2.X = -100;
                    glavni.BrojZivota--;
                    IspisRobe.Invoke();
                }
                if (glavni.TouchingSprite(kravata))
                {
                    Wait(0.1);
                    glavni.BrojZivota--;
                    kravata.Dodir = true;
                    kravata.X = GameOptions.RightEdge;
                    IspisRobe.Invoke();
                }
                if (glavni.TouchingSprite(duksa))
                {
                    Wait(0.1);
                    glavni.BrojZivota--;
                    duksa.Dodir = true;
                    duksa.X = GameOptions.RightEdge;
                    IspisRobe.Invoke();
                }
                if (glavni.TouchingSprite(kupaci))
                {
                    Wait(0.1);
                    glavni.BrojSkupljeneRobe++;
                    kupaci.Dodir = true;
                    kupaci.X = GameOptions.RightEdge;
                    IspisRobe.Invoke();
                }
                if (glavni.TouchingSprite(sesir))
                {
                    Wait(0.1);
                    glavni.BrojSkupljeneRobe++;
                    sesir.Dodir = true;
                    sesir.X = GameOptions.RightEdge;
                    IspisRobe.Invoke();
                }
                if (glavni.TouchingSprite(vesta))
                {
                    Wait(0.1);
                    glavni.BrojSkupljeneRobe++;
                    vesta.Dodir = true;
                    vesta.X = GameOptions.RightEdge;
                    IspisRobe.Invoke();
                }
                if (glavni.TouchingSprite(torba))
                {
                    Wait(0.1);
                    glavni.BrojSkupljeneRobe++;
                    torba.Dodir = true;
                    torba.X = GameOptions.RightEdge;
                    IspisRobe.Invoke();
                }
                if (glavni.TouchingSprite(stikle))
                {
                    Wait(0.1);
                    glavni.BrojSkupljeneRobe++;
                    stikle.Dodir = true;
                    stikle.X = GameOptions.RightEdge;
                    IspisRobe.Invoke();
                }
                Wait(0.1);
                if(dozvoljenaRoba[0].Dodir && dozvoljenaRoba[1].Dodir && dozvoljenaRoba[2].Dodir)
                {
                    Pobjedakraj.Invoke();
                }
            }
            return 0;
        }
        private int Lopov1uZare()
        {
            lopov1.X = GameOptions.RightEdge - 110;
            lopov1.Y = 120;
            Wait(0.1);
            lopov1.SetVisible(true);
            lopov1.Dodir = false;

            while (!lopov1.Dodir)
            {

                lopov1.X -= 20;
                Wait(0.1);
            }

            if (glavni.BrojZivota != 0)
                Game.StartScript(Lopov1uZare);
            return 0;
        }

        private int Lopov2uZare()
        {
            lopov2.X = GameOptions.LeftEdge;
            lopov2.Y = 380;
            Wait(0.1);
            lopov2.SetVisible(true);
            lopov2.Dodir = false;

            while (!lopov2.Dodir)
            {

                lopov2.X -= 20;
                Wait(0.1);
            }

            if (glavni.BrojZivota != 0)
                Game.StartScript(Lopov2uZare);
            return 0;
        }
        private void IspisZaRobu()
        {
            ISPIS = "Broj života: " + glavni.BrojZivota+"/"+GameOptions.broj_zivota+"\nSkupljena odjeća: "+glavni.BrojSkupljeneRobe+"/3";
        }
        private void OdaberiRobu()
        {
            dozvoljenaRoba = new List<Stvari>();

            if (dozvoljenaRoba.Count != 0)
                dozvoljenaRoba.Clear();
            while (dozvoljenaRoba.Count < 3)
            {
                pomocni = listaRobe[r.Next(0, 4)];
                if (!dozvoljenaRoba.Contains(pomocni))
                    dozvoljenaRoba.Add(pomocni);
            }
            dozvoljenaRoba[0].X = 190;
            dozvoljenaRoba[0].Y = 0;
            dozvoljenaRoba[1].X = 400;
            dozvoljenaRoba[1].Y = 270;
            dozvoljenaRoba[2].X = 550;
            dozvoljenaRoba[2].Y = 150;

            foreach (Stvari roba in dozvoljenaRoba)
            {
                if (roba.Naziv == "kupaci")
                    kupaci.SetVisible(true);
                if (roba.Naziv == "sesir")
                    sesir.SetVisible(true);
                if (roba.Naziv == "vesta")
                    vesta.SetVisible(true);
                if (roba.Naziv == "stikle")
                    stikle.SetVisible(true);
                if (roba.Naziv == "torba")
                    torba.SetVisible(true);
            }
            
            
        }
        private void DodajMusku()
        {
            duksa.X = 500;
            duksa.Y = 400;
            kravata.X = 10;
            kravata.Y = 100;
            duksa.SetVisible(true);
            kravata.SetVisible(true);
        }
        #endregion
        private void GlavniKraj()
        {
            Wait(0.1);
            START = false;
            glavni.SetVisible(false);
            lopov.SetVisible(false);
            stokn.SetVisible(false);
            dvjestokn.SetVisible(false);
            petstokn.SetVisible(false);
            lopov1.SetVisible(false);
            lopov2.SetVisible(false);
            duksa.SetVisible(false);
            kupaci.SetVisible(false);
            kravata.SetVisible(false);
            sesir.SetVisible(false);
            stikle.SetVisible(false);
            torba.SetVisible(false);
            vesta.SetVisible(false);
            Wait(0.1);
            setBackgroundPicture("backgrounds\\kraj.jpg");
        }
        private void Pobjeda()
        {
            Wait(0.1);
            START = false;
            glavni.SetVisible(false);
            lopov.SetVisible(false);
            stokn.SetVisible(false);
            dvjestokn.SetVisible(false);
            petstokn.SetVisible(false);
            lopov1.SetVisible(false);
            lopov2.SetVisible(false);
            duksa.SetVisible(false);
            kupaci.SetVisible(false);
            kravata.SetVisible(false);
            sesir.SetVisible(false);
            stikle.SetVisible(false);
            torba.SetVisible(false);
            vesta.SetVisible(false);
            Wait(0.1);
            setBackgroundPicture("backgrounds\\bravo.jpg");
        }
        /* ------------ GAME CODE END ------------ */


    }
}
