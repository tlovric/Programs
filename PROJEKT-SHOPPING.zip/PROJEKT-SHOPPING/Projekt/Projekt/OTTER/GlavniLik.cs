﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Media;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing.Drawing2D;

namespace OTTER
{
    class GlavniLik : Sprite
    {
        private string naziv;
        private int brzina;
        private int brojZivota;
        private int skupi100;
        private int skupi200;
        private int skupi500;
        private int skupi1000;
        private int brojSkupljeneRobe;

        public delegate void EventHandler();
        public event EventHandler KrajIgre;
        public string Naziv { get => naziv; set => naziv = value; }
        public int Brzina { get => brzina; set => brzina = value; }
        public int BrojZivota
        {
            get {  return brojZivota; }
            set
            {
                brojZivota = value;
                if (brojZivota == 0)
                    KrajIgre.Invoke();
            }
        }
    public int Skupi100
        {
            get { return skupi100; }
            set
            {
                if (value > 1000)
                    skupi100 = 1000;
                else
                    skupi100 = value;
            }
        }
        public int Skupi200 
        {
            get { return skupi200; }
            set
            {
                if (value > 1000)
                    skupi200 = 1000;
                else
                    skupi200 = value;
            }
        }
        public int Skupi500
        {
            get { return skupi500; }
            set
            {
                if (value > 1000)
                    skupi500 = 1000;
                else
                    skupi500 = value;
            }
        }
        public int Skupi1000
        {
            get { return this.Skupi100+this.Skupi200+this.Skupi500; }
            set
            {
                skupi1000 = this.Skupi100 + this.Skupi200 + this.Skupi500;
                
            }
        }
        public int BrojSkupljeneRobe
        {
            get { return brojSkupljeneRobe; }
            set { brojSkupljeneRobe = value; }
        }
        public override int Y
        {
            get
            {
                return y;
            }
            set
            {
                if (value > GameOptions.DownEdge - 200)
                    y = GameOptions.DownEdge - 200;
                else if (value < 0)
                    y = 0;
                else
                    y = value;

            }
        }
        public GlavniLik(string spriteImage, int posX, int posY) : base(spriteImage, posX, posY)
        {
            this.Brzina = 10;
            this.BrojZivota = GameOptions.broj_zivota;
        }
        public bool TouchingSprite(Stvari p)
        {
            Sprite s = p;
            if (this.TouchingSprite(s))
            {
                p.Dodir = true;
                return true;
            }
            else
                return false;
        }
    }
}
